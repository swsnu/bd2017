/**
 * Evaluator-side Classes in Logistic Regression on REEF.
 */
package edu.snu.bd.lr.evaluator;
