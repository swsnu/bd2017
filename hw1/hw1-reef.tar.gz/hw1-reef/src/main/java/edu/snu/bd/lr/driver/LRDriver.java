package edu.snu.bd.lr.driver;

import org.apache.reef.tang.annotations.Unit;
import org.apache.reef.wake.EventHandler;
import org.apache.reef.wake.time.event.StartTime;

import javax.inject.Inject;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Driver code that manages Logistic Regression on REEF.
 */
@Unit
public final class LRDriver {
  private static final Logger LOG = Logger.getLogger(LRDriver.class.getName());

  @Inject
  private LRDriver() {
  }

  public final class StartHandler implements EventHandler<StartTime> {
    @Override
    public void onNext(final StartTime startTime) {
      LOG.log(Level.INFO, "Driver is running. Now enjoy REEF coding!");
    }
  }
}
