/**
 * Test classes. You can add unit tests for your LR application (Optional).
 */
package edu.snu.bd;
