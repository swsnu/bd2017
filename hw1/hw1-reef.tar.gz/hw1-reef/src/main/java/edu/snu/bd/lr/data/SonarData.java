package edu.snu.bd.lr.data;

/**
 * Represents an instance of Sonar dataset.
 */
public final class SonarData {
  /**
   * The feature values in the data.
   * features[i] <= 1.0 && features[i] >= 0.0, features.length == 60
   */
  private final double[] features;

  /**
   * Whether the sonar signals bounced off a metal cylinder (labeled as “M”)
   * and those bounced off a rock (labeled as “R”).
   * For the values, 1 is assigned if the label is "M" and 0 otherwise.
   */
  private final int label;

  /**
   * Creates an instance of Sonar data.
   * @param features the feature values in the data.
   * @param label whether the sonar signals bounced off a metal cylinder (labeled as “M”)
   *              and those bounced off a rock (labeled as “R”). The value is assigned to 1 if M and 0 if R.
   */
  public SonarData(final double[] features, final int label) {
    this.features = features;
    this.label = label;
  }

  /**
   * @return The feature values in the data.
   */
  public double[] getFeatures() {
    return features;
  }

  /**
   * @return 1 if M and 0 if R.
   */
  public int getLabel() {
    return label;
  }

}
