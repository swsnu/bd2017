package edu.snu.bd.lr.data;

import org.apache.commons.lang.NotImplementedException;

import javax.inject.Inject;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Loads the sonar dataset and provides the data as a list of {@link SonarData}.
 * {@link #loadData()} currently returns the entire dataset, but you need to modify the method or {@link #getData()}
 * to guarantee each Evaluator takes a disjoint subset of the data.
 */
public final class SonarDataProvider {
  private static final int NUM_INSTANCES = 208;

  private List<SonarData> data;

  @Inject
  private SonarDataProvider() {
    this.data = loadData();
  }

  /**
   * @return the loaded dataset.
   */
  public List<SonarData> getData() {
    return data;
  }

  private List<SonarData> loadData() {
    final List<SonarData> dataset = new ArrayList<>(NUM_INSTANCES);
    try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("sonar.all-data")) {
      try (Scanner scanner = new Scanner(inputStream)) {

        while (scanner.hasNextLine()) {
          final String line = scanner.nextLine();
          dataset.add(parseLine(line));
        }

        return dataset;

      }
    } catch (IOException e) {
      throw new RuntimeException("Failed to load the data file", e);
    }
  }

  /**
   * @param line A line of dataset in text format.
   * @return An instance of Sonar dataset.
   */
  private SonarData parseLine(final String line) {
    throw new NotImplementedException();
  }
}
